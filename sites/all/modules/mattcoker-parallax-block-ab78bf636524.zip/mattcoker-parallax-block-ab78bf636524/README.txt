CONTENTS OF THIS FILE
---------------------

  * Introduction
  * Requirements
  * Installation
  * Configuration
  * Troubleshooting
  * FAQ
  * Future Features
  * Maintainers



INTRODUCTION
------------
The Parallax Block module enables the user to select none, Same, or
Opposite directions when creating a block. Selecting Same or Opposite places
a data-attribute which is ready by the attached javascript file, and then
targeted for calculations causing parallax effect based on 'same' or '
opposite' value.



REQUIREMENTS
------------
  * Use of this module requires Blocks to be enabled.



INSTALLATION
------------
  * Install as usual, see: https://drupal.org/documentation/install/modules-themes/modules-7 for further information.


CONFIGURATION
-------------
  * This module requires no configuration in its initial release. Additional
    releases may change this.
  * There are no permissions associated with this module, although that could be
    added in future updates.
  * To add a background image, CSS must be used at this time using the
    background-image property.


TROUBLESHOOTING
---------------
  * If the option when creating new blocks does not appear, make sure the module
   is enabled. Then, check to see if another module is modifying the block
   creation page.
  * If there are no data-attributes being applied to the blocks when a value has
    been saved, please try updating jQuery with jQuery Updater. After that,
    please submit a bug report.


     FAQ
-------------
  * There are no FAQ at this time.


FUTURE FEATURES
---------------
  * Image upload field on block, that saves the file to a folder (/files/block_backgrounds)
    - URL for resource: http://www.lilianagaete.com/how-to-do-a-file-upload-in-drupal-7/
    - Grab file name, then get block ID and set background-image to file path.
      and set background-size to Cover on internal module CSS file.
    - Added benefit of not including inline styles and causing problems later.
    - Greatly increases usability beyond just parallax, would need to think of
      new name.



MAINTAINERS
-----------
  Current maintainers:
  * Matthew Coker (mattcoker) - https://drupal.org/user/2765587
