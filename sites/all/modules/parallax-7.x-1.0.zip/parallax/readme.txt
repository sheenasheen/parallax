RavindraSingh's sandbox: Parallax blocks
Primary tabs

    View(active tab)
    Edit
    Version control
    Revisions
    Maintainers

Posted by RavindraSingh on March 30, 2014 at 11:39am
Experimental Project

This is a sandbox project, which contains experimental code for developer use only.

What is Parallax?
Parallax scrolling is a special scrolling technique in computer graphics, wherein background images move by the camera slower than foreground images, creating an illusion of depth in a 2D video game and adding to the immersion....

Example of parallax effects :- http://journey.lifeofpimovie.com/

Parallax Blocks is a lightweight module which allows administrator to create parallax blocks. (On every blocks we can add parallax effect).

Module uses the parallax JS library.

Requirements:

Drupal core modules

Block

Installation
Can install via drupal standard process.